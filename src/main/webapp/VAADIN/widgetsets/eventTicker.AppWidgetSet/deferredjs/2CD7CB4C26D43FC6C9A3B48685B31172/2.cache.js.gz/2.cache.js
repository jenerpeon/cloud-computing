$wnd.eventTicker_AppWidgetSet.runAsyncCallback2('Vgb(1772,1,Oge);_.vc=function Aoc(){o5b((!h5b&&(h5b=new t5b),h5b),this.a.d)};nae(Vh)(2);\n//# sourceURL=eventTicker.AppWidgetSet-2.js\n')
